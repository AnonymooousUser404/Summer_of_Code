import numpy as np

class QuadLoss:
    def forward(self, predictions, targets):
        self.predictions = predictions
        self.targets = targets
        loss = 0.5 * np.mean((predictions - targets) ** 2)
        return loss

    def backward(self):
        grad = self.predictions - self.targets
        return grad

class CrossEntropyLoss:
    def forward(self, predictions, targets):
        self.predictions = predictions
        self.targets = targets
        m = targets.shape[0]
        loss = -np.sum(targets * np.log(predictions + 1e-9)) / m
        return loss

    def backward(self):
        grad = self.predictions - self.targets
        return grad



predictions = np.array([[0.69, 0.31], [0.25, 0.75], [0.8, 0.2]])
targets = np.array([[0, 1], [1, 0], [1, 0]])

# QuadLoss
quad_loss = QuadLoss()
quad_loss_value = quad_loss.forward(predictions, targets)
print("QuadLoss value:\n", quad_loss_value)


# CrossEntropyLoss
cross_entropy_loss = CrossEntropyLoss()
cross_entropy_loss_value = cross_entropy_loss.forward(predictions, targets)
print("CrossEntropyLoss value:\n", cross_entropy_loss_value)
