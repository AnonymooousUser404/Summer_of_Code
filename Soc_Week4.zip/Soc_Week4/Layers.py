import numpy as np

class Dense:
    def __init__(self, input_size, output_size):
        self.weights = np.random.randn(input_size, output_size)
        self.biases = np.zeros((1, output_size))

    def forward(self, input_data):
        self.input = input_data
        self.output = np.dot(input_data, self.weights) + self.biases
        return self.output

    def backward(self, grad, learning_rate):
        weights_grad = np.dot(self.input.T, grad)
        input_grad = np.dot(grad, self.weights.T)
        self.weights -= learning_rate * weights_grad
        self.biases -= learning_rate * np.sum(grad, axis=0, keepdims=True)
        return input_grad
    

class Conv2d:
    def __init__(self, input_shape, kernel_shape, num_kernels):
        self.input_shape = input_shape
        self.kernel_shape = kernel_shape
        self.num_kernels = num_kernels
        self.kernels = np.random.randn(num_kernels, *kernel_shape) 
        self.biases = np.zeros((num_kernels, 1))

    def forward(self, input_data):
        self.input = input_data
        self.output = self.traverse_over_input(input_data)
        return self.output

    def traverse_over_input(self, input_data):
        output_height = input_data.shape[0] - self.kernel_shape[0] + 1
        output_width = input_data.shape[1] - self.kernel_shape[1] + 1
        output = np.zeros((self.num_kernels, output_height, output_width))

        for k in range(self.num_kernels):
            kernel = self.kernels[k]
            bias = self.biases[k]
            for i in range(output_height):
                for j in range(output_width):
                    region = input_data[i:i + self.kernel_shape[0], j:j + self.kernel_shape[1]]
                    output[k, i, j] = np.sum(region * kernel) + bias

        return output

    def backward(self, grad, learning_rate):
        grad_k = np.zeros_like(self.kernels)
        grad_x = np.zeros_like(self.input)

        output_height = grad.shape[1]
        output_width = grad.shape[2]

        for k in range(self.num_kernels):
            kernel = self.kernels[k]
            for i in range(output_height):
                for j in range(output_width):
                    region = self.input[i:i + self.kernel_shape[0], j:j + self.kernel_shape[1]]
                    grad_k[k] += grad[k, i, j] * region
                    grad_x[i:i + self.kernel_shape[0], j:j + self.kernel_shape[1]] += grad[k, i, j] * kernel

            self.kernels[k] -= learning_rate * grad_k[k]
            self.biases[k] -= learning_rate * np.sum(grad[k])

        return grad_x


# Define the Dense layer
dense_layer = Dense(input_size=3, output_size=2)
dense_input = np.array([[1, 2, 3]])
dense_output = dense_layer.forward(dense_input)
print("Dense layer output:\n", dense_output)
dense_grad = np.array([[1, 1]])
dense_input_grad = dense_layer.backward(dense_grad, learning_rate=0.01) 
print("Dense layer input gradient:\n", dense_input_grad)

# Define the Conv2d layer
conv_layer = Conv2d(input_shape=(3,3), kernel_shape=(2,2), num_kernels=2)
conv_input = np.random.randn(3,3)
conv_output = conv_layer.forward(conv_input)
print("Conv2d layer output:\n", conv_output)
conv_grad = np.random.randn(2, conv_output.shape[0], conv_output.shape[1])
conv_input_grad = conv_layer.backward(conv_grad, learning_rate=0.01)
print("Conv2d layer input gradient:\n", conv_input_grad)
