import numpy as np

class Sigmoid:
    def forward(self, input_data):
        self.input = input_data
        self.output = 1 / (1 + np.exp(-input_data))
        return self.output

    def backward(self, grad):
        sigmoid_grad = self.output * (1 - self.output)
        return grad * sigmoid_grad

class ReLU:
    def forward(self, input_data):
        self.input = input_data
        self.output = np.maximum(0, input_data)
        return self.output

    def backward(self, grad):
        relu_grad = self.input > 0
        return grad * relu_grad

class Tanh:
    def forward(self, input_data):
        self.input = input_data
        self.output = np.tanh(input_data)
        return self.output

    def backward(self, grad):
        tanh_grad = 1 - np.power(self.output, 2)
        return grad * tanh_grad


n = int(input("Enter the number of elements: "))
input_data = []
for i in range(n):
    input_data.append(float(input(f"Enter element {i + 1}: ")))

input_data = np.array(input_data)
print("Input Data: ", input_data)



# Sigmoid
sigmoid = Sigmoid()
sigmoid_output = sigmoid.forward(input_data)
sigmoid_grad = sigmoid.backward(sigmoid_output)
print("Sigmoid Output:", sigmoid_output)
print("Sigmoid Grad:", sigmoid_grad)

# ReLU
relu = ReLU()
relu_output = relu.forward(input_data)
relu_grad = relu.backward(np.ones_like(relu_output))
print("ReLU Output:", relu_output)
print("ReLU Grad:", relu_grad)

# Tanh
tanh = Tanh()
tanh_output = tanh.forward(input_data)
tanh_grad = tanh.backward(np.ones_like(tanh_output))
print("Tanh Output:", tanh_output)
print("Tanh Grad:", tanh_grad)

