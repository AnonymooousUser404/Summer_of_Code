import numpy as np
from Layers import Dense
from Loss_Function import QuadLoss
# Here i am importing the dense and loss function from the previous files

class Sequential:
    def __init__(self, architecture, loss_function):
        self.architecture = architecture
        self.loss_function = loss_function

    def predict(self, input_data):
        output = input_data
        for layer in self.architecture:
            output = layer.forward(output)
        return output

    def fit(self, X, y,learning_rate):

        output = self.predict(X)
            
        # Compute the loss and the gradient
        loss = self.loss_function.forward(output, y)
        grad = self.loss_function.backward()
            
        # Backward pass
        for layer in reversed(self.architecture):
            grad = layer.backward(grad, learning_rate)
            

architecture = [Dense(input_size=2, output_size=5), Dense(input_size=5, output_size=2)]

model = Sequential(architecture=architecture, loss_function=QuadLoss())


X = np.random.rand(10,2) 
y = np.array([[0.0],[1.0],[0.0],[0.0],[1.0],[0.0],[0.0],[1.0],[0.0],[1.0]]) # these are just arbitrary values


model.fit(X, y,learning_rate=0.01)


predictions = model.predict(X)
print(predictions)
